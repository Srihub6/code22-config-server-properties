package com.edureka.project.inventoryservice.jms.listener;

import javax.jms.JMSException;

import org.apache.activemq.command.ActiveMQObjectMessage;
import org.apache.activemq.command.ActiveMQTextMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

import com.edureka.project.inventoryservice.entity.Businventory;
import com.edureka.project.inventoryservice.entity.repo.BusinventoryRepository;
import com.edureka.project.inventoryservice.model.FullBooking;
import com.edureka.project.inventoryservice.service.InventoryService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

@Component
public class InventoryListener {

    Logger logger = LoggerFactory.getLogger(InventoryListener.class);


    @Autowired
    BusinventoryRepository businventoryRepository;

    @Autowired
    InventoryService inventoryService;

    @JmsListener(destination = "inventory-queue")
    public void receiveMessage(final Object message) throws JMSException, JsonMappingException, JsonProcessingException {

        logger.info("Received inventory update request for {}", message);

        ActiveMQTextMessage message1 = (ActiveMQTextMessage)message;
        System.out.println(message1.getText());
        String temp = message1.getText(). replaceAll("\"", "");;
        
        XmlMapper xmlMapper = new XmlMapper();
        FullBooking fullBooking = xmlMapper.readValue(temp, FullBooking.class);
        System.out.println("Received: " + fullBooking.getStatus());

        inventoryService.processInventoryRequest(fullBooking);
    }
}
