package com.edureka.project.inventoryservice.service;

import com.edureka.project.inventoryservice.entity.Businventory;
import com.edureka.project.inventoryservice.entity.repo.BusinventoryRepository;
import com.edureka.project.inventoryservice.model.FullBooking;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

import javax.jms.JMSException;

@Service
public class InventoryService {

    @Autowired
    BusinventoryRepository businventoryRepository;

    @Autowired
    JmsTemplate jms;

    Logger logger = LoggerFactory.getLogger(InventoryService.class);

    public void processInventoryRequest(FullBooking fullBooking) throws JMSException, JsonMappingException, JsonProcessingException {

        Businventory businventory = businventoryRepository.findById(fullBooking.getServiceid()).get();

        Long freeseats = businventory.getFreeseat();
        if(fullBooking.getStatus().equalsIgnoreCase("PAYMENT_COMPLETED")) {

            freeseats = businventory.getFreeseat() - fullBooking.getPassengers().size();
            if(freeseats > 0) {
                businventory.setFreeseat(freeseats);
                businventoryRepository.save(businventory);
                fullBooking.setStatus("SEATS_RESERVED");
                logger.info("Reserved seats, confirming the booking");
                sendJmsmessage("booking-queue", fullBooking);
            } else {
                fullBooking.setStatus("INSUFFICIENT_SEATS");
                logger.info("Insufficient seats to complete the booking, reverting the payment");
                sendJmsmessage("payments-queue", fullBooking);
            }
        } else if(fullBooking.getStatus().equalsIgnoreCase("PAYMENT_REFUNDED")) {
            freeseats = businventory.getFreeseat() + fullBooking.getPassengers().size();
            fullBooking.setStatus("SEATS_CANCELLED");
            sendJmsmessage("booking-queue", fullBooking);
        }

    }

    public void sendJmsmessage(String queuename, FullBooking fullbooking) throws JsonProcessingException {

        XmlMapper xmlMapper = new XmlMapper();
        String messgae = xmlMapper.writeValueAsString(fullbooking);

        jms.convertAndSend(queuename, messgae);

    }
}
