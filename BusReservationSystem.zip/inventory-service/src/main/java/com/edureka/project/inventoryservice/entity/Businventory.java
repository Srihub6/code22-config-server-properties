package com.edureka.project.inventoryservice.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

@Data
@Entity
@Table(name = "businventory")
public class Businventory implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "serviceid", nullable = false)
    private String serviceid;

    @Column(name = "freeseat", nullable = false)
    private Long freeseat;

    @Column(name = "lastupdated")
    private Date lastupdated;

	public String getServiceid() {
		return serviceid;
	}

	public void setServiceid(String serviceid) {
		this.serviceid = serviceid;
	}

	public Long getFreeseat() {
		return freeseat;
	}

	public void setFreeseat(Long freeseat) {
		this.freeseat = freeseat;
	}

	public Date getLastupdated() {
		return lastupdated;
	}

	public void setLastupdated(Date lastupdated) {
		this.lastupdated = lastupdated;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
    
    

}
