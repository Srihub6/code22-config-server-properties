package com.edureka.project.inventoryservice.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.edureka.project.inventoryservice.entity.Businventory;
import com.edureka.project.inventoryservice.entity.repo.BusinventoryRepository;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.Optional;

@RestController
@RequestMapping("api/v1")
@EnableSwagger2
public class InventoryRestController {

    @Autowired
    BusinventoryRepository businventoryRepository;

    Logger logger = LoggerFactory.getLogger(InventoryRestController.class);

    @GetMapping("get/freeseat/service/{serviceid}")
    public ResponseEntity<Long> getFreeSeatCountByService(@PathVariable String serviceid) {

        logger.info("Fetching free seat availability for service {}", serviceid);

        Optional<Businventory> temp = businventoryRepository.findById(serviceid);
        if (temp.isPresent()) {
            return new ResponseEntity<Long>(temp.get().getFreeseat(), HttpStatus.OK);
        }

        else {
            return new ResponseEntity<>(Long.valueOf(0), HttpStatus.NOT_FOUND);
        }

    }
}
