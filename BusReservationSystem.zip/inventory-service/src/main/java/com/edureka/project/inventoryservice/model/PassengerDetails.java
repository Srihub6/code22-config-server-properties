package com.edureka.project.inventoryservice.model;


import java.io.Serializable;


public class PassengerDetails implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 2342108224105791989L;

	public String name;

    public String gender;

    public int age;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
    

}
