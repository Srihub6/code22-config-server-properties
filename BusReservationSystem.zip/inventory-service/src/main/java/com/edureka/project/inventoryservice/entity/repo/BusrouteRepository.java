package com.edureka.project.inventoryservice.entity.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.edureka.project.inventoryservice.entity.Busroute;

public interface BusrouteRepository extends JpaRepository<Busroute, String>, JpaSpecificationExecutor<Busroute> {

}