package com.edureka.project.adminservice.entity.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.edureka.project.adminservice.entity.Businventory;

public interface BusinventoryRepository extends JpaRepository<Businventory, String>, JpaSpecificationExecutor<Businventory> {

}