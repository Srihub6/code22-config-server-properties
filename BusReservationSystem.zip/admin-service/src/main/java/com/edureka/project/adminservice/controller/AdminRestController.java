package com.edureka.project.adminservice.controller;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.edureka.project.adminservice.entity.Businventory;
import com.edureka.project.adminservice.entity.Busroute;
import com.edureka.project.adminservice.entity.repo.BusinventoryRepository;
import com.edureka.project.adminservice.entity.repo.BusrouteRepository;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("api/v1")
public class AdminRestController {

    Logger logger = LoggerFactory.getLogger(AdminRestController.class);

    @Autowired
    BusrouteRepository busrouteRepository;
    @Autowired
    BusinventoryRepository businventoryRepository;

   //@PreAuthorize("hasRole('ADMIN')")
    @PostMapping("add/route")
    public ResponseEntity<Busroute> addRoute(@RequestBody Busroute busroute) {

        busroute.setServiceid(String.valueOf((int)(Math.random()*100000)));
        busrouteRepository.save(busroute);

        Businventory businventory = new Businventory();
        businventory.setServiceid(busroute.getServiceid());
        businventory.setFreeseat(Long.valueOf(42));
        businventory.setLastupdated(new java.util.Date());
        businventoryRepository.save(businventory);

       return new ResponseEntity<>(busroute, HttpStatus.OK);

    }

    //@PreAuthorize("hasRole('ADMIN')")
    @PostMapping("edit/route")
    public ResponseEntity<Busroute> editRoute(@RequestBody Busroute busroute) {

        Optional<Busroute> temp = busrouteRepository.findById(busroute.getServiceid());
        if(temp.isPresent()) {
            busrouteRepository.delete(temp.get());
            busrouteRepository.save(busroute);
            logger.info("updated bus route to {}", busroute);
            return new ResponseEntity<>(busroute, HttpStatus.OK);
        }
        else {
            logger.error("Route update failed, as no route matched with {}", busroute);
            return new ResponseEntity<>(busroute, HttpStatus.NOT_MODIFIED);
        }

        }

    //@PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("delete/route/{serviceid}")
    ResponseEntity<String> deleteRoute(@PathVariable String serviceid) {

        Optional<Busroute> temp = busrouteRepository.findById(serviceid);
        if(temp.isPresent()) {
            businventoryRepository.deleteById(serviceid);
            busrouteRepository.deleteById(serviceid);
            return new ResponseEntity<>("Deleted bus route", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Bus route not found", HttpStatus.NO_CONTENT);

        }

    }

    @GetMapping("get/route/{serviceid}")
    ResponseEntity<Busroute> getRoute(@PathVariable String serviceid) {

        return new ResponseEntity<>(busrouteRepository.findById(serviceid).get(), HttpStatus.OK);

    }

    @GetMapping("get/all/route")
    ResponseEntity<List<Busroute>> getAllRoutes() {
        return new ResponseEntity<>(busrouteRepository.findAll(), HttpStatus.OK);
    }


}
