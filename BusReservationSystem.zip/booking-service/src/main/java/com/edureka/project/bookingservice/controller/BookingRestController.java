package com.edureka.project.bookingservice.controller;

import java.util.Collections;
import java.util.List;

import javax.jms.JMSException;
import javax.jms.TextMessage;

import org.apache.activemq.command.ActiveMQTextMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;

import com.edureka.project.bookingservice.entity.Booking;
import com.edureka.project.bookingservice.entity.Passenger;
import com.edureka.project.bookingservice.entity.repo.BookingRepository;
import com.edureka.project.bookingservice.entity.repo.PassengerRepository;
import com.edureka.project.bookingservice.model.FullBooking;
import com.edureka.project.bookingservice.model.PassengerDetails;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

import io.github.resilience4j.retry.annotation.Retry;
import reactor.core.publisher.Mono;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@RestController
@RequestMapping("api/v1")
@EnableSwagger2
public class BookingRestController {

    @Autowired
    BookingRepository bookingRepository;

    @Autowired
    WebClient.Builder webClientBuilder;

    @Autowired
    PassengerRepository passengerRepository;

    @Autowired
    JmsTemplate jms;


    Logger logger = LoggerFactory.getLogger(BookingRestController.class);

    //@PreAuthorize("hasRole('USER')")
    @PostMapping("create/booking")
    @Retry(name="default", fallbackMethod="defaultBooking")
    ResponseEntity<Long> createBooking(@RequestBody FullBooking fullbooking) throws JMSException, JsonProcessingException {

        logger.info("Received booking for {} and seats {}", fullbooking.getServiceid(), fullbooking.getPassengers().size());

        Mono<Long> availabeSeats = webClientBuilder.build().get().
                uri("http://gateway-server:8072/inventory-service/api/v1/get/freeseat/service/{serviceid}", fullbooking.getServiceid())
                .retrieve().bodyToMono(Long.class);

        logger.info("Received available seats {}", availabeSeats.block());
        Booking booking = new Booking();

        if(fullbooking.getPassengers().size() < 42) {

            booking.setBookingid(String.valueOf((int)(Math.random()*100000)));

            booking.setNumberofseats((long) fullbooking.getPassengers().size());
            booking.setServiceid(fullbooking.getServiceid());
            booking.setDestination(fullbooking.getDestination());
            booking.setSource(fullbooking.getSource());
            booking.setBookingid(String.valueOf((int)(Math.random()*100000)));
            booking.setStatus("PAYMENT_AWAITING");
            booking.setUsername(fullbooking.getUsername());
            booking.setBookingdate(new java.util.Date());
            bookingRepository.save(booking);
            fullbooking.setBookingid(booking.getBookingid());
            fullbooking.setStatus("PAYMENT_AWAITING");
            
            XmlMapper xmlMapper = new XmlMapper();
            String messgae = xmlMapper.writeValueAsString(fullbooking);

            jms.convertAndSend("payments-queue", messgae);
            logger.info("sent message to payment-service for {}", booking.getBookingid());


        } else {
            logger.error("Not enough free seats to complete the booking");
            booking.setBookingid("0");
        }

        return new ResponseEntity(Long.valueOf(booking.getBookingid()), HttpStatus.OK);

    }
    
    public ResponseEntity<Long> defaultBooking(Exception ex) {
        logger.info("In fallback method of booking......"+ex.getMessage());
        return ResponseEntity.status(HttpStatus.OK).body(0l);
        
    }

    //@PreAuthorize("hasRole('USER')")
    @PostMapping("edit/booking")
    ResponseEntity<Long> updateBooking(@RequestBody FullBooking fullbooking) throws JMSException, JsonProcessingException {

        cancelBooking(fullbooking);
        return createBooking(fullbooking);

    }

    //@PreAuthorize("hasRole('USER')")
    @PostMapping("cancel/booking")
    ResponseEntity<Long> cancelBooking(@RequestBody FullBooking fullbooking) throws JMSException, JsonProcessingException {

        logger.info("Received cancel booking for {} ", fullbooking.getBookingid());

        Booking booking = bookingRepository.findById(fullbooking.getBookingid()).get();
        if(booking.getStatus().equalsIgnoreCase("CONFIRMED")) {
            booking.setStatus("CANCELLING");
            bookingRepository.save(booking);
            fullbooking.setStatus("CANCELLING");
            XmlMapper xmlMapper = new XmlMapper();
            String messgae = xmlMapper.writeValueAsString(fullbooking);

            jms.convertAndSend("payments-queue", messgae);

        }

        return new ResponseEntity(Long.valueOf(booking.getBookingid()), HttpStatus.OK);

    }

    //@PreAuthorize("hasRole('USER')")
    @GetMapping("get/all/bookings")
    public ResponseEntity<List<Booking>> getAllBookings() {
        return new ResponseEntity<List<Booking>>(bookingRepository.findAll(), HttpStatus.OK);
    }

    //@PreAuthorize("hasRole('USER')")
    @GetMapping("get/user/bookings/{username}")
    public ResponseEntity<List<Booking>> getAllBookings(@PathVariable String username) {
        return new ResponseEntity<List<Booking>>(bookingRepository.findBookingsbyUser(username).get(), HttpStatus.OK);
    }
}
