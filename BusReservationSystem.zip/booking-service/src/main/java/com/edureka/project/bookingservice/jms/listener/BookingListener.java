package com.edureka.project.bookingservice.jms.listener;

import org.apache.activemq.command.ActiveMQObjectMessage;
import org.apache.activemq.command.ActiveMQTextMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.edureka.project.bookingservice.entity.Booking;
import com.edureka.project.bookingservice.entity.Passenger;
import com.edureka.project.bookingservice.entity.repo.BookingRepository;
import com.edureka.project.bookingservice.model.FullBooking;
import com.edureka.project.bookingservice.model.PassengerDetails;
import com.edureka.project.bookingservice.service.BookingService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

import javax.jms.JMSException;

@Component
public class BookingListener {

    Logger logger = LoggerFactory.getLogger(BookingListener.class);

    @Autowired
    BookingService bookingService;
    
    @JmsListener(destination = "booking-queue")
    public void receiveMessage(final Object message) throws JMSException, JsonMappingException, JsonProcessingException {

        logger.info("Received booking update request for {}", message);

        ActiveMQTextMessage message1 = (ActiveMQTextMessage)message;
        System.out.println(message1.getText());
        String temp = message1.getText(). replaceAll("\"", "");;
        XmlMapper xmlMapper = new XmlMapper();
        FullBooking fullBooking = xmlMapper.readValue(temp, FullBooking.class);
        System.out.println("Received: " + fullBooking.getStatus());

        bookingService.processBooking(fullBooking);

    }
}
