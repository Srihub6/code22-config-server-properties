package com.edureka.project.bookingservice.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edureka.project.bookingservice.entity.Booking;
import com.edureka.project.bookingservice.entity.Passenger;
import com.edureka.project.bookingservice.entity.repo.BookingRepository;
import com.edureka.project.bookingservice.entity.repo.PassengerRepository;
import com.edureka.project.bookingservice.jms.listener.BookingListener;
import com.edureka.project.bookingservice.model.FullBooking;
import com.edureka.project.bookingservice.model.PassengerDetails;

import java.util.List;

@Service
public class BookingService {

    @Autowired
    BookingRepository bookingRepository;

    @Autowired
    PassengerRepository passengerRepository;

    Logger logger = LoggerFactory.getLogger(BookingService.class);

    public void processBooking(FullBooking fullBooking) {
        Booking booking = bookingRepository.findById(fullBooking.getBookingid()).get();


        if (fullBooking.getStatus().equalsIgnoreCase("SEATS_RESERVED")) {
            booking.setStatus("CONFIRMED");
            logger.info("Booking confirmed, saving passenger info");
            for (PassengerDetails pd : fullBooking.getPassengers()) {
                Passenger passenger = new Passenger();
                passenger.setPassengerid(String.valueOf((int) (Math.random() * 100000)));
                passenger.setBookingid(booking.getBookingid());
                passenger.setServiceid(booking.getServiceid());
                passenger.setPassengerName(pd.getName());
                passenger.setPassengerAge((long) pd.getAge());
                passenger.setGender(pd.getGender());
                passengerRepository.save(passenger);
            }
        } else if (fullBooking.getStatus().equalsIgnoreCase("SEATS_CANCELLED")) {
            booking.setStatus("CANCELLED");
            logger.info("Booking cancelled, removing passenger info");
            List<Passenger> passengers = passengerRepository.findAll();
            for(Passenger passenger : passengers) {
                if(passenger.getBookingid().equals(fullBooking.getBookingid())) {
                    passengerRepository.delete(passenger);
                }
            }
        } else if (fullBooking.getStatus().equalsIgnoreCase("INSUFFICIENT_SEATS")) {
            booking.setStatus("FAILED_TO_RESERVE_SEATS");
        } else if (fullBooking.getStatus().equalsIgnoreCase("INSUFFICIENT_FUNDS")) {
            booking.setStatus("FAILED_IN_PAYMENT");
        }
        bookingRepository.save(booking);

    }

}
