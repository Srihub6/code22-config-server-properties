package com.edureka.project.bookingservice.entity.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.edureka.project.bookingservice.entity.Passenger;

public interface PassengerRepository extends JpaRepository<Passenger, String>, JpaSpecificationExecutor<Passenger> {


}