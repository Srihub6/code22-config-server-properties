package com.edureka.project.bookingservice.entity.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import com.edureka.project.bookingservice.entity.Booking;

import java.util.List;
import java.util.Optional;

public interface BookingRepository extends JpaRepository<Booking, String>, JpaSpecificationExecutor<Booking> {

    @Query(value = "Select * from booking where username = ?", nativeQuery = true)
    public Optional<List<Booking>> findBookingsbyUser(String username);

}