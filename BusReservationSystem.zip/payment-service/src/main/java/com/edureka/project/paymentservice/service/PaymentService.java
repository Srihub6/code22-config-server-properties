package com.edureka.project.paymentservice.service;

import com.edureka.project.paymentservice.entity.Payment;
import com.edureka.project.paymentservice.entity.Userwallet;
import com.edureka.project.paymentservice.entity.repo.PaymentRepository;
import com.edureka.project.paymentservice.entity.repo.UserwalletRepository;
import com.edureka.project.paymentservice.model.FullBooking;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

@Service
public class PaymentService {

    Logger logger = LoggerFactory.getLogger(PaymentService.class);

    @Autowired
    UserwalletRepository userwalletRepository;

    @Autowired
    PaymentRepository paymentRepository;

    @Autowired
    JmsTemplate jms;

    public void processPayment(FullBooking fullBooking) throws JsonProcessingException {

        Long totalPrice = (long) (fullBooking.getFare() * fullBooking.getPassengers().size());
        Userwallet userwallet = userwalletRepository.findById(fullBooking.getUsername()).get();

        if(fullBooking.getStatus().equalsIgnoreCase("PAYMENT_AWAITING")) {
            if (userwallet.getWallet() > totalPrice) {
                logger.info("Fullfilling the payament for bookig: {}", fullBooking.getBookingid());
                Long newBalance = userwallet.getWallet() - totalPrice;
                userwallet.setWallet(newBalance);
                userwalletRepository.save(userwallet);
                Payment payment = new Payment();
                payment.setBookingid(fullBooking.getBookingid());
                payment.setDateofpayment(new java.util.Date());
                payment.setPaymentid(String.valueOf((int)(Math.random()*100000)));
                payment.setAmount(totalPrice);
                payment.setType("BOOKING");
                paymentRepository.save(payment);
                fullBooking.setStatus("PAYMENT_COMPLETED");
                logger.info("updated user wallet for booking, sending inventory update for available seats");
                sendJmsmessage("inventory-queue", fullBooking);

            } else {
                logger.info("User wallet balance is low to complete the booking");
                fullBooking.setStatus("INSUFFICIENT_FUNDS");
                sendJmsmessage("booking-queue", fullBooking);

            }

        } else if(fullBooking.getStatus().equalsIgnoreCase("CANCELLING")) {

            Long refundBalance = userwallet.getWallet() + totalPrice;
            userwallet.setWallet(refundBalance);
            userwalletRepository.save(userwallet);
            logger.info("Refunded user payment for cancellation request, sending inventory reversal request");
            fullBooking.setStatus("PAYMENT_REFUNDED");
            Payment payment = new Payment();
            payment.setBookingid(fullBooking.getBookingid());
            payment.setDateofpayment(new java.util.Date());
            payment.setPaymentid(String.valueOf((int)(Math.random()*100000)));
            payment.setAmount(totalPrice);
            payment.setType("CANCELLING");
            paymentRepository.save(payment);
            sendJmsmessage("inventory-queue", fullBooking);
        } else if(fullBooking.getStatus().equalsIgnoreCase("INSUFFICIENT_SEATS")) {
            Long refundBalance = userwallet.getWallet() + totalPrice;
            userwallet.setWallet(refundBalance);
            userwalletRepository.save(userwallet);
            logger.info("Reverted user payment for INSUFFICIENT_SEATS, sending fail t0 booking service");
            fullBooking.setStatus("INSUFFICIENT_SEATS");
            Payment payment = new Payment();
            payment.setBookingid(fullBooking.getBookingid());
            payment.setDateofpayment(new java.util.Date());
            payment.setPaymentid(String.valueOf((int)(Math.random()*100000)));
            payment.setAmount(totalPrice);
            payment.setType("CANCELLING");
            paymentRepository.save(payment);
            sendJmsmessage("booking-queue", fullBooking);
        }

    }

    public void sendJmsmessage(String queuename, FullBooking fullbooking) throws JsonProcessingException {

        XmlMapper xmlMapper = new XmlMapper();
        String messgae = xmlMapper.writeValueAsString(fullbooking);

        jms.convertAndSend(queuename, messgae);

    }
}
