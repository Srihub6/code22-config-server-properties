package com.edureka.project.paymentservice.jms.listener;

import javax.jms.JMSException;
import javax.transaction.Transactional;

import org.apache.activemq.command.ActiveMQTextMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

import com.edureka.project.paymentservice.entity.Payment;
import com.edureka.project.paymentservice.entity.Userwallet;
import com.edureka.project.paymentservice.entity.repo.PaymentRepository;
import com.edureka.project.paymentservice.entity.repo.UserwalletRepository;
import com.edureka.project.paymentservice.model.FullBooking;
import com.edureka.project.paymentservice.service.PaymentService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

@Component
public class PaymentListener {

    Logger logger = LoggerFactory.getLogger(PaymentListener.class);

    @Autowired
    PaymentService paymentService;

    @Transactional
    @JmsListener(destination = "payments-queue")
    public void receiveMessage(final Object message) throws JMSException, InterruptedException, JsonMappingException, JsonProcessingException {

        logger.info("Received payment request for {}", message);

        ActiveMQTextMessage message1 = (ActiveMQTextMessage)message;
        System.out.println(message1.getText());
        String temp = message1.getText(). replaceAll("\"", "");;
        
        System.out.println(message1.getText());
        XmlMapper xmlMapper = new XmlMapper();
        FullBooking fullBooking = xmlMapper.readValue(temp, FullBooking.class);
       

        System.out.println("Received: " + fullBooking.getStatus());

        paymentService.processPayment(fullBooking);
        

    }
}
