package com.edureka.project.paymentservice.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

@Data
@Entity
@Table(name = "payment")
public class Payment implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "paymentid", nullable = false)
    private String paymentid;

    @Column(name = "bookingid")
    private String bookingid;

    @Column(name = "dateofpayment")
    private Date dateofpayment;
    
    @Column(name = "type")
    private String type;
    
    @Column(name = "amount")
    private Long amount;

	public String getPaymentid() {
		return paymentid;
	}

	public void setPaymentid(String paymentid) {
		this.paymentid = paymentid;
	}

	public String getBookingid() {
		return bookingid;
	}

	public void setBookingid(String bookingid) {
		this.bookingid = bookingid;
	}

	public Date getDateofpayment() {
		return dateofpayment;
	}

	public void setDateofpayment(Date dateofpayment) {
		this.dateofpayment = dateofpayment;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Long getAmount() {
		return amount;
	}

	public void setAmount(Long amount) {
		this.amount = amount;
	}

}
