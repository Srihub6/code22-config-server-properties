package com.edureka.project.paymentservice.entity.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.edureka.project.paymentservice.entity.Userwallet;

public interface UserwalletRepository extends JpaRepository<Userwallet, String>, JpaSpecificationExecutor<Userwallet> {

}